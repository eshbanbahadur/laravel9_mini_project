<?php $__env->startSection('content'); ?>


    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5">
                        <h2>All News</h2>
                    </div>
                </div>

                <div class="col-md-12 text-end mt-4">
                    <a class="btn btn-primary" href="news/create">Add News</a>
                </div>

            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <?php if(session('success')): ?>
                <div>&nbsp;</div>
                <div class="alert alert-danger">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>





    <div class="row justify-content-center mt-5">
        <div class="col-lg-8 margin-tb">
            <table class="table table-bordered">


                <tr>
                    <th>User Id</th>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Action</th>
                </tr>

                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($news->id); ?></td>
                    <td><?php echo e($news->title); ?></td>
                    <td><?php echo e($news->content); ?></td>
                    <td>
                        <form action="<?php echo e(route('news.destroy',$news->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <a class="btn btn-primary" href="<?php echo e(route('news.edit',$news->id)); ?>">Edit</a>
                            <button type="submit" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sample_tasks_backend_eshbanbahadur\resources\views/news/show.blade.php ENDPATH**/ ?>