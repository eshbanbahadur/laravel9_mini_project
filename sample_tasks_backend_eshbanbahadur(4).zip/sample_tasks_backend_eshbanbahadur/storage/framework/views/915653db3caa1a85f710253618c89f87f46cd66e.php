<!DOCTYPE html>

<html>

<head>

    <title>Laravel 9 CRUD Opration - Nicesnippest.com</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>



<div class="container">

    <?php echo $__env->yieldContent('content'); ?>

</div>



</body>

</html>
<?php /**PATH C:\xampp\htdocs\sample_tasks_backend_eshbanbahadur\resources\views/news/layout.blade.php ENDPATH**/ ?>